-- Opțional: doar dacă vrei sincronizare între 2 telefoane.
-- Rulează o singură dată în Supabase → SQL Editor.
create table if not exists public.tracker (
  user_id uuid primary key references auth.users on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.tracker enable row level security;
create policy "doar datele mele" on public.tracker
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
